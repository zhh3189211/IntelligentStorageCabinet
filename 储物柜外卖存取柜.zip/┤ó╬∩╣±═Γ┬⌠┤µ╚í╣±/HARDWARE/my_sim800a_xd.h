#ifndef __MY_SIM800A_XD_H__
#define __MY_SIM800A_XD_H__

//#include "my_include.h"

#include "stm32f10x.h"
#include "usart.h"
#include "delay.h"
#include <string.h> 

#define USART_GSM  USART1

#define LED_GSM_RCC			RCC_APB2Periph_GPIOA
#define LED_GSM_GPIO		GPIOA
#define LED_GSM_GPIO_PIN	GPIO_Pin_8

#define led_gsm PAout(8)

//#define USARTSendString UART_SendString  
//#define USARTSendByte UART_SendByte   

#define NUM_SMS_MSG                     2 //�ڴ��б���������Ϣ�ĸ���
#define LENGTH_PAYLOAD                  32//������Ϣ���ܳ���
#define NUM_GPRS_MSG                    2 //�ڴ��б�������GPRS��Ϣ�ĸ���

typedef struct 
{
    u16 length;//payload���ݳ���
    char telNum[14];
    char payload[LENGTH_PAYLOAD];
    u8 enable;
}_sms_msg_obj;



void My_SIM800_Init(void);
void My_SIM800_StateMachine(unsigned char msgByte);
void My_SIM800_ProcessMessage(void);
void OnGetSMSMessage(const _sms_msg_obj* smsMsgRec);
void My_SIM800_SendSMS(const char *telNum,const  char *sms);

#endif
